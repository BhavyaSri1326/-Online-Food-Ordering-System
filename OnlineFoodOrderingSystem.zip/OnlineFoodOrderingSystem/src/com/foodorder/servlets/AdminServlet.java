package com.foodorder.servlets;

import com.foodorder.dao.OrderDAO;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class AdminServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("orderId");
        String status = request.getParameter("status");
        if(id != null && status != null){
            new OrderDAO().updateStatus(Integer.parseInt(id), status);
        }
        response.sendRedirect("admin.jsp");
    }
}
