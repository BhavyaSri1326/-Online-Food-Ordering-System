package com.foodorder.servlets;

import com.foodorder.dao.UserDAO;
import com.foodorder.model.User;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        User user = new UserDAO().login(email, password);
        if(user != null){
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            if("admin".equalsIgnoreCase(user.getRole())){ response.sendRedirect("admin.jsp"); }
            else { response.sendRedirect("order.jsp"); }
        } else {
            response.sendRedirect("login.jsp?error=1");
        }
    }
}
