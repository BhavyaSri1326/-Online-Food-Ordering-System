package com.foodorder.servlets;

import com.foodorder.dao.UserDAO;
import com.foodorder.model.User;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User user = new User(name, email, password, "customer");
        boolean ok = new UserDAO().registerUser(user);
        response.sendRedirect(ok ? "login.jsp?success=1" : "register.jsp?error=1");
    }
}
