package com.foodorder.servlets;

import com.foodorder.dao.OrderDAO;
import com.foodorder.model.Order;
import com.foodorder.model.User;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class OrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if(session == null || session.getAttribute("user") == null){
            response.sendRedirect("login.jsp");
            return;
        }
        User u = (User) session.getAttribute("user");
        String item = request.getParameter("item");
        int qty = Integer.parseInt(request.getParameter("quantity"));
        double price = Double.parseDouble(request.getParameter("price"));

        Order o = new Order(u.getId(), item, qty, price, "Pending");
        boolean ok = new OrderDAO().placeOrder(o);
        response.sendRedirect(ok ? "order.jsp?placed=1" : "order.jsp?error=1");
    }
}
