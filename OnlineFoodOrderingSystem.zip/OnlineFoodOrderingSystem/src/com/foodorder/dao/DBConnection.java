package com.foodorder.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/foodorder?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root"; // TODO: change to your MySQL user
    private static final String PASS = "password"; // TODO: change to your MySQL password

    public static Connection getConnection() throws SQLException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch (ClassNotFoundException e) { throw new SQLException("MySQL Driver not found", e); }
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
