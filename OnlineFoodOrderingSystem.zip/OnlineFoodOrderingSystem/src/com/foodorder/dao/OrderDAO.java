package com.foodorder.dao;

import com.foodorder.model.Order;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {

    public boolean placeOrder(Order order){
        String sql = "INSERT INTO orders(user_id, item_name, quantity, price, status) VALUES (?, ?, ?, ?, ?)";
        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, order.getUserId());
            ps.setString(2, order.getItemName());
            ps.setInt(3, order.getQuantity());
            ps.setDouble(4, order.getPrice());
            ps.setString(5, order.getStatus());
            return ps.executeUpdate() == 1;
        }catch(SQLException e){
            e.printStackTrace();
            return false;
        }
    }

    public List<Order> getOrdersByUser(int userId){
        List<Order> list = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC";
        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){
            ps.setInt(1, userId);
            try(ResultSet rs = ps.executeQuery()){
                while(rs.next()){
                    Order o = new Order();
                    o.setId(rs.getInt("id"));
                    o.setUserId(rs.getInt("user_id"));
                    o.setItemName(rs.getString("item_name"));
                    o.setQuantity(rs.getInt("quantity"));
                    o.setPrice(rs.getDouble("price"));
                    o.setStatus(rs.getString("status"));
                    list.add(o);
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return list;
    }

    public boolean updateStatus(int orderId, String status){
        String sql = "UPDATE orders SET status=? WHERE id=?";
        try(Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)){
            ps.setString(1, status);
            ps.setInt(2, orderId);
            return ps.executeUpdate() == 1;
        }catch(SQLException e){
            e.printStackTrace();
            return false;
        }
    }
}
