package com.foodorder.model;

public class Order {
    private int id;
    private int userId;
    private String itemName;
    private int quantity;
    private double price;
    private String status;

    public Order(){}
    public Order(int userId, String itemName, int quantity, double price, String status){
        this.userId = userId; this.itemName = itemName; this.quantity = quantity; this.price = price; this.status = status;
    }
    public int getId(){ return id; }
    public void setId(int id){ this.id = id; }
    public int getUserId(){ return userId; }
    public void setUserId(int userId){ this.userId = userId; }
    public String getItemName(){ return itemName; }
    public void setItemName(String itemName){ this.itemName = itemName; }
    public int getQuantity(){ return quantity; }
    public void setQuantity(int quantity){ this.quantity = quantity; }
    public double getPrice(){ return price; }
    public void setPrice(double price){ this.price = price; }
    public String getStatus(){ return status; }
    public void setStatus(String status){ this.status = status; }
}
