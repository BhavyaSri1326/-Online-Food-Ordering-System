<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.sql.*, com.foodorder.dao.DBConnection" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <div class="nav">
        <a href="index.jsp">Home</a>
        <a href="logout">Logout</a>
    </div>
    <h2>Admin - Manage Orders</h2>
    <table>
        <tr><th>ID</th><th>User ID</th><th>Item</th><th>Qty</th><th>Price</th><th>Status</th><th>Action</th></tr>
        <%
            try(Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement("SELECT * FROM orders ORDER BY id DESC");
                ResultSet rs = ps.executeQuery()){
                while(rs.next()){
        %>
        <tr>
            <td><%=rs.getInt("id")%></td>
            <td><%=rs.getInt("user_id")%></td>
            <td><%=rs.getString("item_name")%></td>
            <td><%=rs.getInt("quantity")%></td>
            <td><%=rs.getDouble("price")%></td>
            <td><%=rs.getString("status")%></td>
            <td>
                <form action="updateStatus" method="post" style="display:inline;">
                    <input type="hidden" name="orderId" value="<%=rs.getInt("id")%>">
                    <select name="status">
                        <option>Pending</option>
                        <option>Approved</option>
                        <option>Rejected</option>
                    </select>
                    <button type="submit">Update</button>
                </form>
            </td>
        </tr>
        <%
                }
            } catch(Exception e){
        %>
        <tr><td colspan="7">Error loading orders.</td></tr>
        <%
            }
        %>
    </table>
</div>
</body>
</html>
