<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h2>Login</h2>
    <form action="login" method="post">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
    <p><a href="register.jsp">Create new account</a></p>
    <% if(request.getParameter("error") != null){ %>
    <div class="alert">Invalid credentials. Please try again.</div>
    <% } else if(request.getParameter("success") != null){ %>
    <div class="success">Registration successful. Please log in.</div>
    <% } %>
</div>
</body>
</html>
