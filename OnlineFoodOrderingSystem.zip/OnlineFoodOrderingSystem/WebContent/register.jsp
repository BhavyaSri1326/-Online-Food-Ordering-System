<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h2>Create Account</h2>
    <form action="register" method="post">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Register</button>
    </form>
    <p><a href="login.jsp">Already have an account? Login</a></p>
    <% if(request.getParameter("error") != null){ %>
    <div class="alert">Registration failed. Try a different email.</div>
    <% } %>
</div>
</body>
</html>
