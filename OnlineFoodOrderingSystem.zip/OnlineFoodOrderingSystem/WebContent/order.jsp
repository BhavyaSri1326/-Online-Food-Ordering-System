<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.foodorder.model.User, com.foodorder.dao.OrderDAO, java.util.*" %>
<!DOCTYPE html>
<html>
<head>
    <title>Place Order</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <div class="nav">
        <a href="index.jsp">Home</a>
        <a href="logout">Logout</a>
    </div>
    <h2>Place an Order</h2>
    <%
        User user = (User) session.getAttribute("user");
        if(user == null){ response.sendRedirect("login.jsp"); return; }
    %>
    <form action="placeOrder" method="post">
        <input type="text" name="item" placeholder="Item Name" required>
        <input type="number" name="quantity" placeholder="Quantity" min="1" required>
        <input type="number" step="0.01" name="price" placeholder="Price" required>
        <button type="submit">Place Order</button>
    </form>

    <% if(request.getParameter("placed") != null){ %>
    <div class="success">Order placed successfully!</div>
    <% } else if(request.getParameter("error") != null){ %>
    <div class="alert">Failed to place order. Try again.</div>
    <% } %>

    <h3>Your Orders</h3>
    <%
        com.foodorder.dao.OrderDAO dao = new com.foodorder.dao.OrderDAO();
        java.util.List<com.foodorder.model.Order> orders = dao.getOrdersByUser(user.getId());
        if(orders.isEmpty()){
    %>
        <p>No orders yet.</p>
    <% } else { %>
        <table>
            <tr><th>ID</th><th>Item</th><th>Qty</th><th>Price</th><th>Status</th></tr>
            <% for(com.foodorder.model.Order o : orders){ %>
                <tr>
                    <td><%=o.getId()%></td>
                    <td><%=o.getItemName()%></td>
                    <td><%=o.getQuantity()%></td>
                    <td><%=o.getPrice()%></td>
                    <td><%=o.getStatus()%></td>
                </tr>
            <% } %>
        </table>
    <% } %>
</div>
</body>
</html>
