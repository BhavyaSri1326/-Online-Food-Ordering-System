<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Online Food Ordering</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h1>Online Food Ordering System</h1>
    <div class="card">
        <a href="register.jsp">Create Account</a> | <a href="login.jsp">Login</a>
    </div>
</div>
</body>
</html>
