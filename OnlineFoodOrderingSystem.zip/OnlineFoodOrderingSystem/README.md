# Online Food Ordering System 🍴

Simple **Java + JSP + Servlets + JDBC** project (no MVC).

## Features
- User: Register, Login, Place Order, View Orders
- Admin: View all orders, Update status (Pending/Approved/Rejected)

## Setup
1. Import as **Dynamic Web Project** (Eclipse) or Java EE project.
2. Add **MySQL Connector/J** jar to `lib/` and Build Path.
3. Execute `foodorder.sql` in MySQL.
4. Update DB credentials in `src/com/foodorder/dao/DBConnection.java`.
5. Start Tomcat and open `http://localhost:8080/OnlineFoodOrderingSystem`.

## Default Admin
- Email: `admin@food.com`
- Password: `admin`

Security note: For learning only. Add password hashing & validation for real use.
